img=np.array(image); hsv=cv2.cvtColor(img,cv2.COLOR_RGB2HSV)
mask = cv2.inRange(hsv, np.array([125,5,5]), np.array([175,255,255]))
entire_area = img.shape[0]*img.shape[1]
perc=int(round(100.0*cv2.countNonZero(mask)/entire_area))
result['answer']=str(perc)