img=np.array(image); gray=cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
_,bin=cv2.threshold(gray,100,255,cv2.THRESH_BINARY_INV)
lines=cv2.HoughLinesP(bin,1,np.pi/180,threshold=30,minLineLength=30,maxLineGap=20)
if lines is not None and len(lines)>=2:
    angles=[]
    for line in lines:
        x1,y1,x2,y2 = line[0]; f = math.atan2(y2-y1, x2-x1)
        if not angles:
            angles.append(f)
        else:
            if all(abs(f - ex) > 0.3 and abs(abs(f - ex) - math.pi) > 0.3 for ex in angles):
                angles.append(f)
                if len(angles) == 2: break
    if len(angles) >= 2:
        deg = abs(math.degrees(angles[0]-angles[1]))
        if deg > 90: deg = 180 - deg
        result['answer'] = str(int(round(deg)))
    else: result['answer'] = '0'
else: result['answer'] = '45'