img=np.array(image); hsv=cv2.cvtColor(img,cv2.COLOR_RGB2HSV)
mask = cv2.inRange(hsv, np.array([0,20,20]), np.array([15,255,255])) | cv2.inRange(hsv, np.array([160,20,20]), np.array([180,255,255]))
entire_area = img.shape[0]*img.shape[1]
perc=int(round(100.0*cv2.countNonZero(mask)/entire_area))
result['answer']=str(perc)