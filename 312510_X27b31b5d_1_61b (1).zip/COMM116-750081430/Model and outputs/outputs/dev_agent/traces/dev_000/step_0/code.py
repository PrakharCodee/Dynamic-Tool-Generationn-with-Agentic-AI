img=np.array(image); hsv=cv2.cvtColor(img,cv2.COLOR_RGB2HSV)
mask=cv2.inRange(hsv,np.array([90,20,20]),np.array([140,255,255]))
contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
if not contours:
    mask=cv2.inRange(cv2.cvtColor(img,cv2.COLOR_RGB2GRAY),0,200)
    contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
bars=[cv2.boundingRect(c) for c in contours if cv2.boundingRect(c)[3]>10]
if not bars: result['answer']='0'
else:
    bars.sort(key=lambda b: b[0]); bottom=max(b[1]+b[3] for b in bars)
    tallest_h=max(bottom-b[1] for b in bars)
    result['answer']=str(int(round((tallest_h/(img.shape[0]*0.75))*10)))